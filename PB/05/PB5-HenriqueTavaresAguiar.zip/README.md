# PB 5 - Programação em Bioinformática

## Identificação de Quadros de Leitura

### Dependências

Esse programa foi  escrito com Python 3.8.5, e não necessita de instalação de módulos externos

### Execução

Para rodar o programa, dentro do diretório onde está esse programa execute o seguinte comando:

    python <nome do programa>.py
ou

    python3 <nome do programa>.py

E pronto, se tudo ocorreu como deveria, um arquivo chamado 'orfs.fasta' foi gerado como resultado no mesmo diretório deste programa.
